/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projeto_caminho._solidario;

import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.mindrot.jbcrypt.BCrypt;

/**
 *
 * @Barbara
 */
public class Cadastro_Usuário extends javax.swing.JInternalFrame {

    String idPessoa, situacao;

   public Cadastro_Usuário(boolean mostrarMensagem) {
    initComponents();
    atualizar_tabela();

    setMaximizable(true);
    try {
        setMaximum(true);
    } catch (java.beans.PropertyVetoException e) {
        e.printStackTrace();
    }

    setVisible(true);

    if (mostrarMensagem) {
        JOptionPane.showMessageDialog(this, "Bem-vindo(a) ao cadastro! ✨");
    }
}
   public Cadastro_Usuário() {
    this(true); // Chama o outro construtor e exibe a mensagem por padrão
}

    @SuppressWarnings("unchecked")

    
    
    
    public void atualizar_tabela() {

        DefaultTableModel tabelaModelo = (DefaultTableModel) tabela.getModel();
        tabelaModelo.setRowCount(0);

        try {

            Connection con = Conexao.conexaoBanco();
            String sql = "SELECT "
                    + "p.idPessoa, p.nome_completo, p.cpf, p.telefone, p.email, "
                    + "l.situacao, l.senha "
                    + "FROM pessoa p "
                    + "INNER JOIN login l ON p.cpf = l.cpf "
                    + "ORDER BY p.idPessoa";

            PreparedStatement stmt = con.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Object[] dados = {
                    rs.getString("idPessoa"),
                    rs.getString("nome_completo"),
                    rs.getString("cpf"),
                    rs.getString("telefone"),
                    rs.getString("email"),
                    rs.getString("situacao"),
                    rs.getString("senha")
                };
                tabelaModelo.addRow(dados);
            }

            nome.setText(null);
            cpf.setText(null);
            email.setText(null);
            telefone.setText(null);
            senha.setText(null);
            cfSenha.setText(null);

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Erro ao atualizar tabela: " + ex.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        nome = new javax.swing.JTextField();
        cpf = new javax.swing.JTextField();
        telefone = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        btCadastrar = new javax.swing.JButton();
        btExcluir = new javax.swing.JButton();
        btAlterar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        senha = new javax.swing.JPasswordField();
        jLabel9 = new javax.swing.JLabel();
        cfSenha = new javax.swing.JPasswordField();
        cbSituacao = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("CADASTRO DE NOVOS USUÁRIOS");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/logo_semNome (2).png"))); // NOI18N
        jLabel2.setText("\n");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("NOME");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("E-MAIL");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("CPF");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("TELEFONE");

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/whatsapp.png"))); // NOI18N

        btCadastrar.setBackground(new java.awt.Color(0, 153, 255));
        btCadastrar.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        btCadastrar.setForeground(new java.awt.Color(255, 255, 255));
        btCadastrar.setText("CADASTRAR");
        btCadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btCadastrarMouseClicked(evt);
            }
        });

        btExcluir.setBackground(new java.awt.Color(0, 153, 255));
        btExcluir.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        btExcluir.setForeground(new java.awt.Color(255, 255, 255));
        btExcluir.setText("EXCLUIR");
        btExcluir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btExcluirMouseClicked(evt);
            }
        });

        btAlterar.setBackground(new java.awt.Color(0, 153, 255));
        btAlterar.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        btAlterar.setForeground(new java.awt.Color(255, 255, 255));
        btAlterar.setText("ALTERAR");
        btAlterar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btAlterarMouseClicked(evt);
            }
        });

        tabela.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOME", "CPF", "TELEFONE", "E-MAIL", "DESIGNAÇÃO"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabela.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tabela.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabela);
        tabela.getAccessibleContext().setAccessibleName("");

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/logoRodaPe.png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("SENHA");

        senha.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("CONFIRMAR SENHA");

        cfSenha.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        cbSituacao.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        cbSituacao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Administrador", "Voluntário" }));
        cbSituacao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSituacaoActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setText("DESIGNAÇÃO");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(110, 110, 110)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbSituacao, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 145, Short.MAX_VALUE)
                                .addComponent(telefone, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel8))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(cpf, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, 427, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(senha, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cfSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1236, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(137, 137, 137)
                        .addComponent(btAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(137, 137, 137)
                        .addComponent(btExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(279, 279, 279))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1))
                                .addGap(5, 5, 5)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(cpf, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addGap(5, 5, 5)
                                .addComponent(senha, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel8))
                        .addGap(5, 5, 5)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cfSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))))
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(telefone, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel6)
                        .addComponent(jLabel5)))
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cbSituacao, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btCadastrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btCadastrarMouseClicked

        try {
            Connection con = Conexao.conexaoBanco();

            // 1. Inserir na tabela pessoa e capturar o idPessoa gerado
            String sqlPessoa = "INSERT INTO pessoa (nome_completo, cpf, telefone, email) VALUES (?,?,?,?)";
            PreparedStatement stmtPessoa = con.prepareStatement(sqlPessoa, Statement.RETURN_GENERATED_KEYS);
            stmtPessoa.setString(1, nome.getText());
            stmtPessoa.setString(2, cpf.getText());
            stmtPessoa.setString(3, telefone.getText());
            stmtPessoa.setString(4, email.getText());
            stmtPessoa.executeUpdate();

            int idPessoa = 0;
            ResultSet rsPessoa = stmtPessoa.getGeneratedKeys();
            if (rsPessoa.next()) {
                idPessoa = rsPessoa.getInt(1);
            }
            rsPessoa.close();
            stmtPessoa.close();

            // 2. Definir situação (Administrador ou Voluntário)
            String situacao;
            if (cbSituacao.getSelectedItem().toString().equals("Administrador")) {
                situacao = "A";
            } else {
                situacao = "V";
            }

            // 3. Inserir na tabela login, vinculando ao idPessoa
            String sqlLogin = "INSERT INTO login (senha, cpf, situacao, idPessoa) VALUES (UPPER(MD5(?)),?,?,?)";
            PreparedStatement stmtLogin = con.prepareStatement(sqlLogin);
            stmtLogin.setString(1, senha.getText());
            stmtLogin.setString(2, cpf.getText());
            stmtLogin.setString(3, situacao);
            stmtLogin.setInt(4, idPessoa);
            stmtLogin.executeUpdate();

            stmtLogin.close();
            con.close();

            // 4. Atualiza a tabela na interface
            atualizar_tabela();

            // 5. Confirmação visual
            JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!");

        } catch (SQLException ex) {
            Logger.getLogger(Cadastro_Usuário.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btCadastrarMouseClicked

    private void btAlterarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btAlterarMouseClicked

        try {
            Connection con = Conexao.conexaoBanco();
            String sql = "UPDATE pessoa SET nome_completo = ?, cpf = ?, email = ?, telefone = ? WHERE idPessoa = ? ";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nome.getText());
            stmt.setString(2, cpf.getText());
            stmt.setString(3, email.getText());
            stmt.setString(4, telefone.getText());
            stmt.setString(5, idPessoa);

            stmt.executeUpdate();

            try {
                String sql1 = "UPDATE login SET senha = ?, situacao = ? WHERE cpf = ?";
                PreparedStatement stmt1 = con.prepareStatement(sql1);

                stmt1.setString(1, senha.getText());

                if (cbSituacao.getSelectedItem().toString().equals("Administrador")) {
                    situacao = "A";
                } else {
                    situacao = "V";

                }
                stmt1.setString(2, situacao);
                stmt1.setString(3, cpf.getText());
                stmt1.executeUpdate();

                JOptionPane.showMessageDialog(null, "Cadastro Alterado com Sucesso!");
                stmt1.close();

            } catch (SQLException ex) {
                Logger.getLogger(Cadastro_Usuário.class.getName()).log(Level.SEVERE, null, ex);
            }
            atualizar_tabela();
            stmt.close();
            con.close();

        } catch (SQLException ex) {
            Logger.getLogger(Cadastro_Usuário.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btAlterarMouseClicked

    private void tabelaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaMouseClicked
        if (tabela != null) {
            System.out.println(tabela.toString());
        } else {
            System.out.println("Valor nulo encontrado!");
        }
        int linhaSelecionada = tabela.getSelectedRow();

        if (linhaSelecionada >= 0) {
            idPessoa = tabela.getValueAt(tabela.getSelectedRow(), 0).toString();
            nome.setText(tabela.getValueAt(tabela.getSelectedRow(), 1).toString());
            cpf.setText(tabela.getValueAt(tabela.getSelectedRow(), 2).toString());
            telefone.setText(tabela.getValueAt(tabela.getSelectedRow(), 3).toString());
            email.setText(tabela.getValueAt(tabela.getSelectedRow(), 4).toString());
            cbSituacao.setSelectedItem(tabela.getValueAt(linhaSelecionada, 5).toString());
        }
    }//GEN-LAST:event_tabelaMouseClicked

    private void btExcluirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btExcluirMouseClicked
        try {
            Connection con = Conexao.conexaoBanco();

            // Primeiro, apagar os logins vinculados à pessoa
            String sql = "DELETE FROM login WHERE idPessoa = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, idPessoa);
            stmt.executeUpdate();
            stmt.close();

            // Agora, apagar a pessoa
            sql = "DELETE FROM pessoa WHERE idPessoa = ?;";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, idPessoa);
            stmt.executeUpdate();
            stmt.close();

            JOptionPane.showMessageDialog(null, "Cadastro Deletado com Sucesso!");

            // Atualizar a tabela
            DefaultTableModel tabelaModelo = (DefaultTableModel) tabela.getModel();
            tabelaModelo.setNumRows(0);

            sql = "SELECT idPessoa, nome_completo, cpf, email, telefone FROM pessoa;";
            stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            atualizar_tabela(); // Certifique-se de que essa função usa o ResultSet corretamente

            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException ex) {
            Logger.getLogger(Cadastro_Usuário.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao deletar cadastro:\n" + ex.getMessage());
        }

    }//GEN-LAST:event_btExcluirMouseClicked

    private void cbSituacaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSituacaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbSituacaoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAlterar;
    private javax.swing.JButton btCadastrar;
    private javax.swing.JButton btExcluir;
    private javax.swing.JComboBox<String> cbSituacao;
    private javax.swing.JPasswordField cfSenha;
    private javax.swing.JTextField cpf;
    private javax.swing.JTextField email;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField nome;
    private javax.swing.JPasswordField senha;
    private javax.swing.JTable tabela;
    private javax.swing.JTextField telefone;
    // End of variables declaration//GEN-END:variables
}
