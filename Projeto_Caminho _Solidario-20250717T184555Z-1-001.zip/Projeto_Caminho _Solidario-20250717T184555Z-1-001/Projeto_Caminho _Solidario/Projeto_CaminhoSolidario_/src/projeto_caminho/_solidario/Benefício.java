/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projeto_caminho._solidario;

import com.toedter.calendar.JDateChooser;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Usuário
 */
public class Benefício extends javax.swing.JInternalFrame {

    String datas, data, datass, idPessoa, idBeneficio, idBeneficiario;

    public Benefício() {
        initComponents();
        addBeneficiario_comboBox();
        
        setMaximizable(true);
        // Maximizar a janela ao abrir
        try {
            setMaximum(true);
        } catch (java.beans.PropertyVetoException e) {
            e.printStackTrace();
        }
        setVisible(true);

    }

    public String getDatas() {
        return datas;

    }

    private void addBeneficiario_comboBox() {
        try {
            Connection con = Conexao.conexaoBanco();

            // Consulta os IDs dos beneficiários
            String sql = "SELECT idPessoa FROM beneficiario";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            // Consulta preparada para obter o nome com base no ID
            String sql1 = "SELECT nome_completo FROM pessoa WHERE idPessoa = ?";
            PreparedStatement stmt1 = con.prepareStatement(sql1);

            while (rs.next()) {
                int idPessoa = rs.getInt("idPessoa");

                stmt1.setInt(1, idPessoa);
                ResultSet rs1 = stmt1.executeQuery();

                if (rs1.next()) {
                    String nomeCompleto = rs1.getString("nome_completo");
                    cbBeneficiario.addItem(nomeCompleto);
                }

                rs1.close();
            }

            stmt1.close();
            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException ex) {
            Logger.getLogger(Cadastro_Filho_Dependente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void atualizar_Tabela() {

        DefaultTableModel tabelaModelo = (DefaultTableModel) tabela.getModel();
        tabelaModelo.setNumRows(0);

        try {
            Connection con = Conexao.conexaoBanco();
            String sql = "SELECT * FROM vw_beneficio_pessoa;";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Object[] dados = {
                    rs.getString("ID"),
                    rs.getString("idPessoa"),
                    rs.getString("nome_completo"),
                    rs.getString("data_cadastro"),
                    rs.getString("data_entrada"),
                    rs.getString("data_saida"),
                    rs.getString("prorrogacao"),
                    rs.getString("duracao"),
                    rs.getString("situacao_beneficio")
                };
                tabelaModelo.addRow(dados);
            }

            cbBeneficiario.setSelectedItem(null);
            dataCadastro.setDate(null);
            dataEntrada.setDate(null);
            dataSaida.setDate(null);
            prorrogacao.setText(null);
            duracao.setText(null);
            cbSituacao.setSelectedItem(null);

            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException ex) {
            Logger.getLogger(Benefício.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao atualizar a tabela:\n" + ex.getMessage());
        }

    }

    @SuppressWarnings("unchecked")


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        dataCadastro = new com.toedter.calendar.JDateChooser();
        dataEntrada = new com.toedter.calendar.JDateChooser();
        dataSaida = new com.toedter.calendar.JDateChooser();
        lbBairro3 = new javax.swing.JLabel();
        lbBairro4 = new javax.swing.JLabel();
        lbBairro5 = new javax.swing.JLabel();
        prorrogacao = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cbSituacao = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        btCadastrar = new javax.swing.JButton();
        btAlterar = new javax.swing.JButton();
        btExcluir = new javax.swing.JButton();
        lbBairro6 = new javax.swing.JLabel();
        duracao = new javax.swing.JTextField();
        cbBeneficiario = new javax.swing.JComboBox<>();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("BENEFÍCIO - AUXÍLIO CESTA BÁSICA");

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOME", "DATA DO CADASTRO", "ENTRADA", "SAÍDA", "PRORROGAÇÃO", "DURAÇÃO", "SITUAÇÃO"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabela.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabela);

        lbBairro3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbBairro3.setText("BENEFICIÁRIO");

        lbBairro4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbBairro4.setText("DATA DA ENTRADA");

        lbBairro5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbBairro5.setText("DATA DA SAÍDA");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/logo_semNome (2).png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("PRORROGAÇÃO*");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("DURAÇÃO");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("SITUAÇÃO");

        cbSituacao.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        cbSituacao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ativo", "Inativo" }));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/logoRodaPe.png"))); // NOI18N

        btCadastrar.setBackground(new java.awt.Color(0, 153, 204));
        btCadastrar.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        btCadastrar.setForeground(new java.awt.Color(255, 255, 255));
        btCadastrar.setText("CADASTRAR");
        btCadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btCadastrarMouseClicked(evt);
            }
        });

        btAlterar.setBackground(new java.awt.Color(0, 153, 204));
        btAlterar.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        btAlterar.setForeground(new java.awt.Color(255, 255, 255));
        btAlterar.setText("ALTERAR");
        btAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAlterarActionPerformed(evt);
            }
        });

        btExcluir.setBackground(new java.awt.Color(0, 153, 204));
        btExcluir.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        btExcluir.setForeground(new java.awt.Color(255, 255, 255));
        btExcluir.setText("EXCLUIR");

        lbBairro6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbBairro6.setText("DATA DO CADASTRO");

        cbBeneficiario.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(110, 110, 110)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbBairro5)
                            .addComponent(lbBairro4)
                            .addComponent(lbBairro3)
                            .addComponent(jLabel2)
                            .addComponent(lbBairro6)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cbSituacao, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dataEntrada, javax.swing.GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
                            .addComponent(dataCadastro, javax.swing.GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
                            .addComponent(dataSaida, javax.swing.GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
                            .addComponent(prorrogacao, javax.swing.GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
                            .addComponent(duracao, javax.swing.GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
                            .addComponent(cbBeneficiario, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel5)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 24, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
            .addGroup(layout.createSequentialGroup()
                .addGap(293, 293, 293)
                .addComponent(btCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(133, 133, 133)
                .addComponent(btAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(137, 137, 137)
                .addComponent(btExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lbBairro3)
                            .addComponent(cbBeneficiario, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(5, 5, 5)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(dataCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbBairro6))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(dataEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbBairro4)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(dataSaida, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbBairro5)
                                .addGap(2, 2, 2))))
                    .addComponent(jLabel1))
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(prorrogacao, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(duracao, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(cbSituacao, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAlterarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btAlterarActionPerformed

    private void btCadastrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btCadastrarMouseClicked
        
        SimpleDateFormat dataformatada = new SimpleDateFormat("yyyy-MM-dd");
        String datass = dataformatada.format(dataCadastro.getDate());
        String datas = dataformatada.format(dataEntrada.getDate());
        String data = dataformatada.format(dataSaida.getDate());

        try {
            Connection con = Conexao.conexaoBanco();

            String sql = "INSERT INTO beneficio (data_cadastro, data_entrada, data_saida, prorrogacao, "
                    + "duracao, situacao_beneficio, idPessoa, idBeneficiario) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, (SELECT idBeneficiario FROM beneficiario "
                    + "WHERE idPessoa = (SELECT idPessoa FROM pessoa WHERE nome_completo = ? LIMIT 1)))";

            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, datass); 
            stmt.setString(2, datas);  
            stmt.setString(3, data);   
            stmt.setString(4, prorrogacao.getText());
            stmt.setString(5, duracao.getText());
            stmt.setString(6, cbSituacao.getSelectedItem().toString());
            stmt.setString(7, idPessoa); 
            stmt.setString(8, cbBeneficiario.getSelectedItem().toString()); 

            stmt.execute();

            stmt.close();
            con.close();
            atualizar_Tabela();
            
            JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!");

        } catch (SQLException ex) {
            ex.printStackTrace();
            Logger.getLogger(Benefício.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btCadastrarMouseClicked

    private void tabelaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaMouseClicked


    }//GEN-LAST:event_tabelaMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAlterar;
    private javax.swing.JButton btCadastrar;
    private javax.swing.JButton btExcluir;
    private javax.swing.JComboBox<String> cbBeneficiario;
    private javax.swing.JComboBox<String> cbSituacao;
    private com.toedter.calendar.JDateChooser dataCadastro;
    private com.toedter.calendar.JDateChooser dataEntrada;
    private com.toedter.calendar.JDateChooser dataSaida;
    private javax.swing.JTextField duracao;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbBairro3;
    private javax.swing.JLabel lbBairro4;
    private javax.swing.JLabel lbBairro5;
    private javax.swing.JLabel lbBairro6;
    private javax.swing.JTextField prorrogacao;
    private javax.swing.JTable tabela;
    // End of variables declaration//GEN-END:variables
}
