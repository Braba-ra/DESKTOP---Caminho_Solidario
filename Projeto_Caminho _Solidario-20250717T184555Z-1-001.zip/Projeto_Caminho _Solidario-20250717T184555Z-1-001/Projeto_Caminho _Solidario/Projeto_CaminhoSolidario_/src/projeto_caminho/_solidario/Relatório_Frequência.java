/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projeto_caminho._solidario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Usuário
 */
public class Relatório_Frequência extends javax.swing.JInternalFrame {

    String idFrequencia, mes;
    
    public Relatório_Frequência() {
        initComponents();
         buscarCpfCompleto();

        setMaximizable(true);

        // Maximizar a janela ao abrir
        try {
            setMaximum(true);
        } catch (java.beans.PropertyVetoException e) {
            e.printStackTrace();
        }

        setVisible(true);
     
        
    }

   
    @SuppressWarnings("unchecked")
     public void buscarCpfCompleto() {
    }

    public void buscarCpfCompleto(String cpfParcial) {

        try {

            Connection con = Conexao.conexaoBanco();

            // Consulta para buscar um CPF que começa com os 5 primeiros dígitos
            String sql = "SELECT cpf FROM pessoa WHERE cpf LIKE ? LIMIT 1";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, cpfParcial + "%"); // Busca CPFs que começam com os dígitos informados

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                cpf.setText(rs.getString("cpf")); // Preenche o campo com o CPF completo
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum CPF encontrado com esses números.");
            }

            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Relatório_Frequência.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        cpf = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        cbAno = new javax.swing.JComboBox<>();
        btGerarRelatorio = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("CONTROLE DE FREQUÊNCIA");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/logo_semNome (2).png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("CPF");

        cpf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cpfKeyReleased(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setText("ANO");

        cbAno.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        cbAno.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2023", "2024", "2025" }));

        btGerarRelatorio.setBackground(new java.awt.Color(0, 153, 204));
        btGerarRelatorio.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btGerarRelatorio.setForeground(new java.awt.Color(255, 255, 255));
        btGerarRelatorio.setText("GERAR RELATÓRIO");
        btGerarRelatorio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btGerarRelatorioMouseClicked(evt);
            }
        });
        btGerarRelatorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btGerarRelatorioActionPerformed(evt);
            }
        });

        tabela.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CPF", "ANO", "REGISTRO"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tabela);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/logoRodaPe.png"))); // NOI18N

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 0, 0));
        jLabel3.setText("EM MANUTENÇÃO");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/optimizing.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(53, 53, 53)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(cpf, javax.swing.GroupLayout.PREFERRED_SIZE, 397, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(150, 150, 150)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(cbAno, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4)
                                .addGap(79, 79, 79))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(334, 334, 334)
                        .addComponent(btGerarRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1202, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(cpf, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(5, 5, 5)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel9)
                                .addComponent(cbAno, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btGerarRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 399, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cpfKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cpfKeyReleased
        String cpfDigitado = cpf.getText().trim();

        // Verifica se há exatamente 5 dígitos
        if (cpfDigitado.length() == 5) {
            buscarCpfCompleto(cpfDigitado);
        }

        cpf.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cpfKeyReleased(evt);
            }

        });

    }//GEN-LAST:event_cpfKeyReleased

    private void btGerarRelatorioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btGerarRelatorioMouseClicked
        try {
            Connection con = Conexao.conexaoBanco();

            // Consulta SQL para buscar CPF, Registro e Mês filtrados corretamente
            String sql = "SELECT  registro, mes FROM frequencia WHERE registro = ? AND ano = ?";

            PreparedStatement stmt = con.prepareStatement(sql);

            // Definir os parâmetros corretamente conforme a consulta
            stmt.setString(1, cpf.getText()); // Pegando CPF do campo de text
            
            stmt.setString(2,cbAno.getSelectedItem().toString());

            ResultSet rs = stmt.executeQuery();

            // Modelo para armazenar os meses na lista
            // DefaultListModel<String> lista = new DefaultListModel<>();
            DefaultTableModel tabelaFrequencia = (DefaultTableModel) tabela.getModel();
            tabelaFrequencia.setNumRows(0);

            while (rs.next()) {
                Object[] dados = {rs.getString("cpf"),rs.getString("mes")};
                tabelaFrequencia.addRow(dados);
                // lista.addElement("CPF: " + rs.getString("cpf") + " - Registro: " + rs.getString("registro") + " - Mês: " + rs.getString("mes"));
            }

            rs.close();
            stmt.close();
            con.close();

            // Atualiza a interface gráfica corretamente
            /*  SwingUtilities.invokeLater(() -> {
                JList<String> listagem = new JList<>(lista);
                JOptionPane.showMessageDialog(null, new JScrollPane(listagem), "Registros Encontrados", JOptionPane.INFORMATION_MESSAGE);
            });*/

        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Relatório_Frequência.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btGerarRelatorioMouseClicked

    private void btGerarRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btGerarRelatorioActionPerformed

    }//GEN-LAST:event_btGerarRelatorioActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btGerarRelatorio;
    private javax.swing.JComboBox<String> cbAno;
    private javax.swing.JTextField cpf;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tabela;
    // End of variables declaration//GEN-END:variables
}
