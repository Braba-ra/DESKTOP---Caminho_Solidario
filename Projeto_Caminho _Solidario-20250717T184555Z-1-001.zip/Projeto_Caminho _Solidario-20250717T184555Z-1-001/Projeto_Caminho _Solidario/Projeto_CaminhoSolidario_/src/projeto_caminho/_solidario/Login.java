/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projeto_caminho._solidario;

import com.formdev.flatlaf.FlatLaf;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Color;
import java.awt.Font;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import projeto_caminho._solidario.Menu;

/**
 *
 * @author Usuário
 */
public class Login extends javax.swing.JFrame {

    public static void main(String args[]) {
        try {
            FlatLaf.registerCustomDefaultsSource("flatlaf"); // 👈 Esta linha vem primeiro
            UIManager.setLookAndFeel(new FlatLightLaf());    // 👈 Agora o visual será aplicado com seu estilo
        } catch (Exception e) {
            System.err.println("Erro ao aplicar FlatLaf: " + e);
        }

        java.awt.EventQueue.invokeLater(() -> {
            new Login().setVisible(true);
        });
    }

    public Login() {
        initComponents();
        estilizarBotaoLogin();
        aplicarIconeLogin();
        estilizarBotaoCadastrar();
         aplicarHoverBotao(btCadastrar);
    }

    private void aplicarIconeLogin() {
        URL iconeLogin = getClass().getResource("/IMG/login.png");
        if (iconeLogin != null) {
            btLogin.setIcon(new ImageIcon(iconeLogin));
        } else {
            System.out.println("⚠️ Ícone não encontrado: /IMG/login.png");
        }
    }

    private void estilizarBotaoLogin() {
        Font fonteMac = new Font("Segoe UI", Font.PLAIN, 14);
        btLogin.setFont(fonteMac);
        btLogin.setFocusPainted(false);
        btLogin.setHorizontalTextPosition(SwingConstants.RIGHT);
        btLogin.setIconTextGap(10);
        btLogin.putClientProperty("JButton.buttonType", "default");
    }

    private void estilizarBotaoCadastrar() {
    Font fonteMac = new Font("Segoe UI", Font.PLAIN, 14); // Fonte clean
    btCadastrar.setFont(fonteMac);
    btCadastrar.setFocusPainted(false); // Remove contorno no clique
    btCadastrar.setBackground(new Color(245, 245, 245)); // Fundo claro
    btCadastrar.setForeground(new Color(30, 30, 30));    // Texto escuro
    btCadastrar.putClientProperty("JButton.buttonType", "default");
}
    
private void aplicarHoverBotao(JButton botao) {
    // Cor original
    Color corNormal = new Color(245, 245, 245);
    // Cor quando passa o mouse
    Color corHover = new Color(230, 230, 230);

    botao.setBackground(corNormal); // cor padrão

    botao.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {
            botao.setBackground(corHover); // muda cor ao entrar
        }

        public void mouseExited(java.awt.event.MouseEvent evt) {
            botao.setBackground(corNormal); // volta ao normal ao sair
        }
    });
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        cpf = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        senha = new javax.swing.JPasswordField();
        btLogin = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btCadastrar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Bodoni MT", 1, 24)); // NOI18N
        jLabel1.setText("CPF");

        jLabel2.setFont(new java.awt.Font("Bodoni MT", 1, 24)); // NOI18N
        jLabel2.setText("SENHA");

        btLogin.setBackground(new java.awt.Color(0, 153, 204));
        btLogin.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btLogin.setForeground(new java.awt.Color(255, 255, 255));
        btLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/login.png"))); // NOI18N
        btLogin.setText("LOGIN");
        btLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btLoginMouseClicked(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Não tem uma conta?");

        btCadastrar.setBackground(new java.awt.Color(0, 153, 204));
        btCadastrar.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        btCadastrar.setForeground(new java.awt.Color(255, 255, 255));
        btCadastrar.setText("CADASTRAR-SE");
        btCadastrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btCadastrarMouseClicked(evt);
            }
        });
        btCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCadastrarActionPerformed(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/logoRodaPe.png"))); // NOI18N

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/logo_semNome (1).png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(85, 85, 85)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(btCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(363, 363, 363)
                                .addComponent(btLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(100, 100, 100)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(99, 99, 99))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addGap(62, 62, 62)))
                                .addComponent(cpf, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(241, 241, 241)
                                .addComponent(senha, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 61, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel3)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cpf, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(senha, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48)
                .addComponent(btLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 87, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(194, 194, 194))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)))
                .addComponent(jLabel3)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btLoginMouseClicked
        try {

            Connection con = Conexao.conexaoBanco();
            String sql = "SELECT * FROM login WHERE cpf = ? AND senha = UPPER(MD5(?))";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, cpf.getText());
            stmt.setString(2, senha.getText());

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Menu mcs = new Menu();
                mcs.setVisible(true);
                JOptionPane.showMessageDialog(this, "Login bem-sucedido! ✨");

            } else {
                JOptionPane.showMessageDialog(this, "CPF ou senha incorretos.");
            }

        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btLoginMouseClicked

    private void btCadastrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btCadastrarMouseClicked

    }//GEN-LAST:event_btCadastrarMouseClicked

    private void btCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCadastrarActionPerformed

        dispose();

        Menu telaMenu = new Menu();
        telaMenu.setVisible(true);

        for (JInternalFrame frame : telaMenu.getPainel().getAllFrames()) {
            if (frame instanceof Cadastro_Usuário) {
                frame.toFront();
                return;
            }
        }

        Cadastro_Usuário cu = new Cadastro_Usuário();
        telaMenu.getPainel().add(cu);
        cu.setVisible(true);

        cu.setLocation(
                (telaMenu.getPainel().getWidth() - cu.getWidth()) / 2,
                (telaMenu.getPainel().getHeight() - cu.getHeight()) / 2
        );


    }//GEN-LAST:event_btCadastrarActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btCadastrar;
    private javax.swing.JButton btLogin;
    private javax.swing.JTextField cpf;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPasswordField senha;
    // End of variables declaration//GEN-END:variables
}
