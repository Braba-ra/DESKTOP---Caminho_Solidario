/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package projeto_caminho._solidario;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

public class Registro_de_Frequência extends javax.swing.JInternalFrame {

     String registro;
     
     
    public Registro_de_Frequência() {
        initComponents();
         buscarCpfCompleto();
        atualizarTabela();

        setMaximizable(true);

        // Maximizar a janela ao abrir
        try {
            setMaximum(true);
        } catch (java.beans.PropertyVetoException e) {
            e.printStackTrace();
        }

        setVisible(true);
    
    }

   
    @SuppressWarnings("unchecked")
    
     public void atualizarTabela() {
        try {

            Connection con = Conexao.conexaoBanco();
            String sql = " SELECT * FROM frequencia ORDER BY idFrequencia";
            PreparedStatement stmt = con.prepareStatement(sql);

            ResultSet rs = stmt.executeQuery();

            DefaultTableModel tabelaModelo = (DefaultTableModel) tabela.getModel();
            tabelaModelo.setNumRows(0);

            while (rs.next()) {
                Object[] dados = {
                    rs.getString("idFrequencia"),
                    rs.getString("cpf"),
                    rs.getString("ano"),
                    rs.getString("mes")
                };
                tabelaModelo.addRow(dados);
            }

            cpf.setText(null);

        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Registro_de_Frequência.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

    }

    public void buscarCpfCompleto() {
        
    }

    public void buscarCpfCompleto(String cpfParcial) {

        try {

            Connection con = Conexao.conexaoBanco();

            // Consulta para buscar um CPF que começa com os 5 primeiros dígitos
            String sql = "SELECT cpf FROM pessoa WHERE cpf LIKE ? LIMIT 1";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, cpfParcial + "%"); // Busca CPFs que começam com os dígitos informados

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                cpf.setText(rs.getString("cpf")); // Preenche o campo com o CPF completo
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum CPF encontrado com esses números.");
            }

            rs.close();
            stmt.close();
            con.close();

        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Registro_de_Frequência.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cpf = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cbAno = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        cbMes = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        cbFrequencia = new javax.swing.JComboBox<>();
        btRegistrar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("REGISTRO DE FREQUÊNCIA");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/logo_semNome (2).png"))); // NOI18N

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("CPF");

        cpf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cpfKeyReleased(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("ANO");

        cbAno.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        cbAno.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2023", "2024", "2025" }));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setText("MÊS");

        cbMes.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        cbMes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "JANEIRO  ", "FEVEREIRO  ", "MARÇO  ", "ABRIL  ", "MAIO  ", "JUNHO  ", "JULHO  ", "AGOSTO  ", "SETEMBRO  ", "OUTUBRO  ", "NOVEMBRO  ", "DEZEMBRO" }));
        cbMes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbMesActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setText("FREQUÊNCIA");

        cbFrequencia.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        cbFrequencia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "P", "F" }));

        btRegistrar.setBackground(new java.awt.Color(0, 153, 204));
        btRegistrar.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        btRegistrar.setForeground(new java.awt.Color(255, 255, 255));
        btRegistrar.setText("REGISTRAR");
        btRegistrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btRegistrarMouseClicked(evt);
            }
        });

        tabela.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "CPF", "ANO", "MÊS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabela);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/logoRodaPe.png"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(110, 110, 110)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel7)
                    .addComponent(jLabel3))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbFrequencia, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(cpf, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(btRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(cbAno, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel6)))
                            .addGap(18, 18, 18)
                            .addComponent(cbMes, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 367, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1202, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(cpf, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(cbAno, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbMes, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(14, 14, 14)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cbFrequencia, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addComponent(btRegistrar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cpfKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cpfKeyReleased

        String cpfDigitado = cpf.getText().trim();

        
        if (cpfDigitado.length() == 5) {
            buscarCpfCompleto(cpfDigitado);
        }

        cpf.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cpfKeyReleased(evt);
            }
        });
        
    }//GEN-LAST:event_cpfKeyReleased

    private void cbMesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbMesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbMesActionPerformed

    private void btRegistrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btRegistrarMouseClicked

        try {
            Connection con = Conexao.conexaoBanco();

            String sql = "INSERT INTO frequencia (cpf, ano, mes, registro) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, cpf.getText());
            stmt.setString(2, cbAno.getSelectedItem().toString());
            stmt.setString(3, cbMes.getSelectedItem().toString());

            // Obtém a escolha do usuário (P ou F)
            String registroEscolhido = cbFrequencia.getSelectedItem().toString();
            stmt.setString(4, registroEscolhido);

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Registro atualizado com sucesso!");

            stmt.close();
            con.close();

            atualizarTabela();

        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(Registro_de_Frequência.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btRegistrarMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btRegistrar;
    private javax.swing.JComboBox<String> cbAno;
    private javax.swing.JComboBox<String> cbFrequencia;
    private javax.swing.JComboBox<String> cbMes;
    private javax.swing.JTextField cpf;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabela;
    // End of variables declaration//GEN-END:variables
}
